Editable Explainer Studio IR v1.0. Source archive and secrets are excluded.
Subtitle timing is estimated. See quality.json. Media paths are in manifest.json.
