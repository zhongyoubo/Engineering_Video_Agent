Editable Explainer Studio IR v1.0. Source archive and secrets are excluded.
Alignment method is recorded in quality.json. See alignment report in the application. Media paths are in manifest.json.
