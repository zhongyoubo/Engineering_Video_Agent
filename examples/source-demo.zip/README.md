# Directory Sync Demo

A standard-library example that identifies changed file contents using SHA-256 hashes. It uses dictionaries as fixtures and does not modify the filesystem.

Run: python sync_demo.py
